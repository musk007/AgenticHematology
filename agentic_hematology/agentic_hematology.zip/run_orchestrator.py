"""
run_orchestrator.py
===================
Entry point showing how to wire the full agentic pipeline with the
two-model detector (YOLOv11 + EfficientNet) under the orchestrator.

Two modes:

  # Development — stub detector replays precomputed JSON (no GPU/models):
  python run_orchestrator.py \\
      --case-id 12 \\
      --backend stub --stub-source examples/sample_cases.json \\
      --instruction "Generate a full diagnostic report"

  # Production — real YOLOv11 + EfficientNet:
  python run_orchestrator.py \\
      --case-id PT-0042 \\
      --backend two-stage \\
      --yolo-weights weights/yolov11_lld.pt \\
      --effnet-weights weights/effnet_attrs.ts \\
      --images "data/PT-0042/*.png" \\
      --instruction "Generate a full diagnostic report" \\
      --report-backend claude
"""

from __future__ import annotations

import argparse
import glob
import json
import sys

from leukemia_pipeline.detection_agent import StubDetector
from leukemia_pipeline.leukemia_classifier import HybridClassifier, LearnedClassifier
from leukemia_pipeline.orchestrator import (
    Orchestrator,
    OrchestratorRequest,
    RuleBasedRouter,
)
from leukemia_pipeline.report_generator import (
    ClaudeReportGenerator,
    OpenAIReportGenerator,
    TemplateReportGenerator,
)


def build_detector(args):
    if args.backend == "stub":
        return StubDetector(args.stub_source)
    if args.backend == "two-stage":
        # Imported lazily so the stub path doesn't require torch/ultralytics.
        from leukemia_pipeline.detection_agent_v2 import (
            TwoStageDetectionAgent,
            YOLOv11Localizer,
            EfficientNetAttributeClassifier,
        )
        localizer = YOLOv11Localizer(
            weights_path=args.yolo_weights,
            conf_threshold=args.conf_threshold,
            iou_threshold=args.iou_threshold,
            device=args.device,
        )
        attr_clf = EfficientNetAttributeClassifier(
            weights_path=args.effnet_weights,
            device=args.device,
            predicts_cell_type=args.effnet_predicts_celltype,
        )
        return TwoStageDetectionAgent(
            localizer=localizer,
            attribute_classifier=attr_clf,
            prefer_efficientnet_celltype=args.effnet_predicts_celltype,
        )
    sys.exit(f"Unknown backend: {args.backend}")


def build_report_generator(args):
    if args.report_backend == "template":
        return TemplateReportGenerator()
    if args.report_backend == "claude":
        return ClaudeReportGenerator()
    if args.report_backend == "openai":
        return OpenAIReportGenerator()
    sys.exit(f"Unknown report backend: {args.report_backend}")


def resolve_images(args) -> list[str]:
    if not args.images:
        return []
    paths: list[str] = []
    for spec in args.images:
        paths.extend(sorted(glob.glob(spec)))
    return paths


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--case-id", required=True)
    p.add_argument("--backend", choices=["stub", "two-stage"], default="stub")
    p.add_argument("--stub-source")
    p.add_argument("--yolo-weights")
    p.add_argument("--effnet-weights")
    p.add_argument("--effnet-predicts-celltype", action="store_true")
    p.add_argument("--images", nargs="*")
    p.add_argument("--conf-threshold", type=float, default=0.25)
    p.add_argument("--iou-threshold", type=float, default=0.5)
    p.add_argument("--device", default=None)
    p.add_argument("--classifier-model", help="Optional pickled sklearn model.")
    p.add_argument("--report-backend", choices=["template", "claude", "openai"], default="template")
    p.add_argument("--instruction", default="Generate a full diagnostic report")
    p.add_argument("--out")
    args = p.parse_args()

    detector = build_detector(args)
    learned = LearnedClassifier(model_path=args.classifier_model) if args.classifier_model else None
    classifier = HybridClassifier(learned=learned)
    report_gen = build_report_generator(args)

    orch = Orchestrator(
        detector=detector,
        classifier=classifier,
        report_generator=report_gen,
        router=RuleBasedRouter(),
    )

    req = OrchestratorRequest(
        case_id=args.case_id,
        image_paths=resolve_images(args),
        instruction=args.instruction,
    )
    resp = orch.handle(req)

    print(f"Intent: {resp.intent.value}  ({resp.routing_rationale})")
    if resp.state.errors:
        print("Errors:", file=sys.stderr)
        for e in resp.state.errors:
            print(f"  - {e}", file=sys.stderr)

    if resp.answer:
        print("\n" + resp.answer)

    if resp.state.report:
        if args.out:
            import os
            os.makedirs(args.out, exist_ok=True)
            path = os.path.join(args.out, f"case_{args.case_id}_report.md")
            with open(path, "w") as f:
                f.write(resp.state.report.markdown)
            print(f"Wrote {path}")
            print(f"  consistency_passed={resp.state.consistency_passed} "
                  f"llm_output_passed={resp.state.llm_output_passed}")
        else:
            print("\n" + resp.state.report.markdown)

    return 0


if __name__ == "__main__":
    sys.exit(main())
