"""
detection_agent_v2.py
=====================
Two-model detection + attribute-classification agent.

Architecture (the design you specified):

    image ──▶ YOLOv11 localizer ──▶ bbox + cell-type per cell
                                         │
                                         ▼
                         crop each cell from the image
                                         │
                                         ▼
              EfficientNet attribute classifier (per crop)
                                         │
                                         ▼
              Detection objects with bbox + cell_type + 7 attributes

This separates the two learnable components cleanly:
- `YOLOv11Localizer`     — wraps an Ultralytics YOLOv11 model. Produces
                            bounding boxes + cell-type labels + objectness.
- `EfficientNetAttributeClassifier` — wraps a (multi-head) EfficientNet that
                            takes a cell crop and predicts the 7 morphologic
                            attributes. One classification head per attribute.
- `TwoStageDetectionAgent` — orchestrates the two: localize, crop, classify,
                            assemble `Detection` objects.

All three conform to the same `DetectionResult` contract the rest of the
pipeline already consumes, so nothing downstream changes.

Backends degrade gracefully: if torch / ultralytics are not installed, the
classes raise a clear ImportError only when instantiated, so the module
still imports for testing with the StubDetector.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Any

from .detection_agent import BaseDetectionAgent, LLD_CLASSES, ATTRIBUTE_VOCAB
from .schemas import Detection, DetectionResult


# ---------------------------------------------------------------------------
# Attribute schema — the 7 LLD morphologic attributes and their value vocab.
# The EfficientNet has one classification head per attribute; head i outputs
# a distribution over ATTRIBUTE_ORDER[i]'s vocabulary.
# ---------------------------------------------------------------------------

ATTRIBUTE_ORDER = [
    "cell_size",
    "nuclear_chromatio",
    "nuclear_shape",
    "nucleolus",
    "cytoplasm",
    "cytoplasmic_basophilia",
    "cytoplasmic_vacuoles",
]


# ---------------------------------------------------------------------------
# Stage 1 — YOLOv11 localizer
# ---------------------------------------------------------------------------

class YOLOv11Localizer:
    """
    Wraps an Ultralytics YOLOv11 model trained on the LLD 14-class schema.

    Produces, per image, a list of (bbox_xyxy, cell_type, objectness).
    Cell-type comes from the YOLO classification head; if you trained YOLO
    only for localization (single 'cell' class), set `class_agnostic=True`
    and let EfficientNet handle typing too (not the default).
    """

    def __init__(
        self,
        weights_path: str,
        conf_threshold: float = 0.25,
        iou_threshold: float = 0.5,
        device: str | None = None,
        class_agnostic: bool = False,
    ):
        try:
            from ultralytics import YOLO  # type: ignore
        except ImportError as e:
            raise ImportError(
                "Install ultralytics for YOLOv11: `pip install ultralytics`"
            ) from e
        self.model = YOLO(weights_path)
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        self.device = device
        self.class_agnostic = class_agnostic

    def localize(self, image_paths: list[str]) -> dict[str, list[dict[str, Any]]]:
        """
        Returns {image_path: [{bbox_xyxy, cell_type, objectness}, ...]}.
        """
        results = self.model.predict(
            source=image_paths,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            device=self.device,
            verbose=False,
        )

        out: dict[str, list[dict[str, Any]]] = {}
        for img_path, r in zip(image_paths, results):
            cells: list[dict[str, Any]] = []
            if r.boxes is not None and len(r.boxes) > 0:
                xyxy = r.boxes.xyxy.cpu().numpy()
                confs = r.boxes.conf.cpu().numpy()
                cls_ids = r.boxes.cls.cpu().numpy().astype(int)
                for i in range(len(xyxy)):
                    if self.class_agnostic:
                        cell_type = "Unknown"
                    else:
                        cid = int(cls_ids[i])
                        cell_type = LLD_CLASSES[cid] if cid < len(LLD_CLASSES) else "None"
                    cells.append({
                        "bbox_xyxy": tuple(float(v) for v in xyxy[i]),
                        "cell_type": cell_type,
                        "objectness": float(confs[i]),
                    })
            out[img_path] = cells
        return out


# ---------------------------------------------------------------------------
# Stage 2 — EfficientNet attribute classifier
# ---------------------------------------------------------------------------

class EfficientNetAttributeClassifier:
    """
    Wraps a multi-head EfficientNet that classifies the 7 morphologic
    attributes from a single cell crop.

    Expected model contract:
    - input: a batch tensor of shape (N, 3, H, W), normalised.
    - output: a dict {attribute_name: logits_tensor of shape (N, n_values)}
      OR a list of 7 logit tensors in ATTRIBUTE_ORDER.

    If your EfficientNet also predicts cell-type (8th head), set
    `predicts_cell_type=True` and expose it under key "cell_type"; the
    two-stage agent will prefer it over YOLO's type when available.
    """

    def __init__(
        self,
        weights_path: str,
        device: str | None = None,
        image_size: int = 224,
        predicts_cell_type: bool = False,
    ):
        try:
            import torch  # type: ignore
            from torchvision import transforms  # type: ignore
        except ImportError as e:
            raise ImportError(
                "Install torch + torchvision for EfficientNet: "
                "`pip install torch torchvision`"
            ) from e
        self._torch = torch
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.predicts_cell_type = predicts_cell_type

        # Load the traced/scripted model or a state-dict-backed nn.Module.
        # We accept either a TorchScript file or a checkpoint with a
        # `build_model` you provide; here we assume TorchScript for simplicity.
        self.model = torch.jit.load(weights_path, map_location=self.device)
        self.model.eval()

        # Standard ImageNet normalisation; adjust if you trained differently.
        self.preprocess = transforms.Compose([
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225],
            ),
        ])

    def classify_crops(
        self, crops: list["Any"]
    ) -> list[tuple[dict[str, str], dict[str, float], str | None, float | None]]:
        """
        :param crops: list of PIL.Image cell crops.
        :return: list of (attributes, attribute_probs, cell_type, cell_type_prob)
                 aligned with `crops`. cell_type is None unless the model
                 predicts it.
        """
        torch = self._torch
        if not crops:
            return []

        batch = torch.stack([self.preprocess(c) for c in crops]).to(self.device)
        with torch.no_grad():
            raw = self.model(batch)

        # Normalise raw output to dict[name -> logits].
        logits_by_attr = self._coerce_output(raw)

        results = []
        n = batch.shape[0]
        for i in range(n):
            attrs: dict[str, str] = {}
            attr_probs: dict[str, float] = {}
            for attr in ATTRIBUTE_ORDER:
                logits = logits_by_attr[attr][i]
                probs = torch.softmax(logits, dim=-1)
                idx = int(torch.argmax(probs).item())
                vocab = ATTRIBUTE_VOCAB[attr]
                attrs[attr] = vocab[idx] if idx < len(vocab) else "na"
                attr_probs[attr] = float(probs[idx].item())

            cell_type = None
            cell_type_prob = None
            if self.predicts_cell_type and "cell_type" in logits_by_attr:
                ct_logits = logits_by_attr["cell_type"][i]
                ct_probs = torch.softmax(ct_logits, dim=-1)
                ct_idx = int(torch.argmax(ct_probs).item())
                cell_type = LLD_CLASSES[ct_idx] if ct_idx < len(LLD_CLASSES) else "None"
                cell_type_prob = float(ct_probs[ct_idx].item())

            results.append((attrs, attr_probs, cell_type, cell_type_prob))
        return results

    def _coerce_output(self, raw: Any) -> dict[str, Any]:
        """Accept dict or ordered-list model outputs; return a name->logits dict."""
        if isinstance(raw, dict):
            return raw
        # Assume a list/tuple in ATTRIBUTE_ORDER (+ optional cell_type last).
        names = list(ATTRIBUTE_ORDER)
        if self.predicts_cell_type:
            names = names + ["cell_type"]
        return {name: raw[i] for i, name in enumerate(names)}


# ---------------------------------------------------------------------------
# Two-stage agent
# ---------------------------------------------------------------------------

class TwoStageDetectionAgent(BaseDetectionAgent):
    """
    Combines YOLOv11 localization with EfficientNet attribute classification.

    Flow per case:
    1. YOLOv11 localizes cells in every image → bboxes + cell types.
    2. Each cell is cropped from its source image.
    3. EfficientNet classifies the 7 attributes for each crop (and optionally
       refines the cell-type).
    4. Assemble Detection objects with stable cell_ids.
    """

    def __init__(
        self,
        localizer: YOLOv11Localizer,
        attribute_classifier: EfficientNetAttributeClassifier,
        crop_padding: int = 4,
        prefer_efficientnet_celltype: bool = False,
    ):
        self.localizer = localizer
        self.attribute_classifier = attribute_classifier
        self.crop_padding = crop_padding
        self.prefer_efficientnet_celltype = prefer_efficientnet_celltype

    def detect(self, case_id: str, image_paths: list[str]) -> DetectionResult:
        try:
            from PIL import Image  # type: ignore
        except ImportError as e:
            raise ImportError("Install Pillow: `pip install Pillow`") from e

        # Stage 1: localize.
        per_image_cells = self.localizer.localize(image_paths)

        all_detections: list[Detection] = []
        for img_idx, img_path in enumerate(image_paths):
            cells = per_image_cells.get(img_path, [])
            if not cells:
                continue

            image_id = os.path.basename(img_path)
            with Image.open(img_path) as im:
                im = im.convert("RGB")
                W, H = im.size

                # Crop all cells from this image.
                crops = []
                for c in cells:
                    x1, y1, x2, y2 = c["bbox_xyxy"]
                    x1 = max(0, int(x1) - self.crop_padding)
                    y1 = max(0, int(y1) - self.crop_padding)
                    x2 = min(W, int(x2) + self.crop_padding)
                    y2 = min(H, int(y2) + self.crop_padding)
                    crops.append(im.crop((x1, y1, x2, y2)))

                # Stage 2: classify attributes for all crops in this image.
                attr_results = self.attribute_classifier.classify_crops(crops)

            for cell_idx, (c, attr_res) in enumerate(zip(cells, attr_results)):
                attrs, attr_probs, en_cell_type, en_cell_type_prob = attr_res

                # Decide final cell type.
                if self.prefer_efficientnet_celltype and en_cell_type is not None:
                    cell_type = en_cell_type
                    cell_type_prob = en_cell_type_prob or c["objectness"]
                else:
                    cell_type = c["cell_type"]
                    cell_type_prob = c["objectness"]

                all_detections.append(Detection(
                    cell_id=f"img{img_idx:03d}_c{cell_idx:03d}",
                    image_id=image_id,
                    bbox_xyxy=c["bbox_xyxy"],
                    cell_type=cell_type,
                    objectness=c["objectness"],
                    cell_type_prob=cell_type_prob,
                    attributes=attrs,
                    attribute_probs=attr_probs,
                ))

        return DetectionResult(
            case_id=case_id,
            n_images=len(image_paths),
            detections=all_detections,
        )
